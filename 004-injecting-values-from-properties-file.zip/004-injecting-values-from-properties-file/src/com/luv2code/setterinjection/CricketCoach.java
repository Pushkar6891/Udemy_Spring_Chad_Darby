package com.luv2code.setterinjection;

public class CricketCoach implements Coach {

	private FortuneService fortuneService;

	private String email;
	private String team;

	public CricketCoach() {
		System.out.println("Inside CricketCoach()");
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		System.out.println("Inside setter method setEmail");
		this.email = email;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		System.out.println("Inside setter method setTeam");
		this.team = team;
	}

	/// when we inject the dependency this method is called
	public void setFortuneService(FortuneService fortuneService) {
		System.out.println("Inside setter method setFortuneService");
		this.fortuneService = fortuneService;
	}

	@Override
	public String getDailyWorkout() {
		return "Practise fast bowling";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

}
