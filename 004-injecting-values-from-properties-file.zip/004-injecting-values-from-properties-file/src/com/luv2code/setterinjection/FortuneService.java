package com.luv2code.setterinjection;

public interface FortuneService {

	public String getFortune();
}
