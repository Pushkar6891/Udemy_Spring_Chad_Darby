package com.luv2code.hibernate.demo.usingutil;

import java.util.List;

public class Tester {
	public static void main(String[] args) {
		EmployeeDao employeeDao = new EmployeeDao();
		Employee employee = new Employee("Ramesh", "Fadatare", "rameshfadatare@javaguides.com");
		employeeDao.saveEmployee(employee);
		List<Employee> employees = employeeDao.getEmployees();
		employees.forEach(s -> System.out.println(s.getFirstName()));
	}
}