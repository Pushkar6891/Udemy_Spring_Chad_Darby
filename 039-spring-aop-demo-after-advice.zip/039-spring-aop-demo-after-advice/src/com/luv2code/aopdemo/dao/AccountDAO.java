package com.luv2code.aopdemo.dao;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO {

	public void helloWorld() {
		System.out.println("Hello World!!!");
	}
}
