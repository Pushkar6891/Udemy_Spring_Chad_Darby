package com.luv2code.setterinjection;

public interface Coach {

	public String getDailyWorkout();
	public String getDailyFortune();
}
