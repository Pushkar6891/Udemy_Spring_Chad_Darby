package com.luv2code.jackson.json.demo;

import java.io.Reader;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Driver {

	public static void main(String[] args) {

		try {
			// read json file data to String
			byte[] jsonData = Files.readAllBytes(Paths.get("data/sample-full.json"));

			// create object mapper
			ObjectMapper objectMapper = new ObjectMapper();

			// read JSON file
			Student theStudent = objectMapper.readValue(jsonData, Student.class);

			// print firstName and lastName
			System.out.println("First Name: " + theStudent.getFirstName());
			System.out.println("Last Name: " + theStudent.getLastName());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
