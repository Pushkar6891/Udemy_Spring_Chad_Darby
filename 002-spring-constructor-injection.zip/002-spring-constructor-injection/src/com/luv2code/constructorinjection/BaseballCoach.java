package com.luv2code.constructorinjection;

public class BaseballCoach implements Coach {

	private FortuneService fortuneService;

	public BaseballCoach() {

	}

	public BaseballCoach(FortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}

	@Override
	public String getDailyWorkout() {
		return "spend 30 minutes on batting practise";
	}

	@Override
	public String getDailyFortune() {

		// use fortuneService to get a fortune
		return fortuneService.getFortune();
	}
}
