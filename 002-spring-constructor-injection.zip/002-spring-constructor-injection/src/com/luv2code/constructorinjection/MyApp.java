package com.luv2code.constructorinjection;

public class MyApp {

	public static void main(String[] args) {

		// create object
		Coach coach = new TrackCoach();

		// use object
		System.out.println(coach.getDailyWorkout());
	}

}
