package com.luv2code.constructorinjection;

public interface Coach {

	public String getDailyWorkout();
	public String getDailyFortune();
}
