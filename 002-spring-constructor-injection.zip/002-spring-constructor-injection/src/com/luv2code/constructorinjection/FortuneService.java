package com.luv2code.constructorinjection;

public interface FortuneService {

	public String getFortune();
}
